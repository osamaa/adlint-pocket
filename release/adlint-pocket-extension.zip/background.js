// src/background.js
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "adlint-check-selection",
    title: "Check with AdLint Pocket",
    contexts: ["selection"]
  });
});
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {
});
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "adlint-check-selection" || !info.selectionText) return;
  await chrome.sidePanel.open({ windowId: tab.windowId });
  await chrome.storage.session.set({ pendingText: info.selectionText });
});
//# sourceMappingURL=background.js.map
